/*     */ package survivors;
/*     */ 
/*     */ import baseWars.BaseWars;
/*     */ import java.util.logging.Logger;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class survivorWall extends JavaPlugin
/*     */   implements Listener
/*     */ {
/*  21 */   public final Logger logger = Logger.getLogger("Minecraft");
/*  22 */   public Material wallMaterial = Material.DIRT;
/*  23 */   public byte wallMaterialData = 0;
/*     */   public static BaseWars plugin;
/*     */ 
/*     */   public survivorWall(BaseWars plugin)
/*     */   {
/*  27 */     plugin = plugin;
/*  28 */     plugin.getServer().getPluginManager().registerEvents(this, plugin);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.HIGHEST)
/*     */   public void onPlayerInteract(PlayerInteractEvent e) {
/*  33 */     Player player = e.getPlayer();
/*     */ 
/*  35 */     if (((e.getAction() == Action.RIGHT_CLICK_BLOCK) || (e.getAction() == Action.RIGHT_CLICK_AIR)) && 
/*  36 */       (player
/*  36 */       .getItemInHand().getType().equals(Material.BRICK))) {
/*  37 */       Block targetBlock = player.getTargetBlock(null, 10);
/*  38 */       Block one = targetBlock.getRelative(BlockFace.UP);
/*  39 */       Block three = one.getRelative(BlockFace.NORTH_WEST);
/*  40 */       Block four = one.getRelative(BlockFace.NORTH);
/*  41 */       Block five = one.getRelative(BlockFace.NORTH_EAST);
/*  42 */       Block six = one.getRelative(BlockFace.WEST);
/*  43 */       Block seven = one.getRelative(BlockFace.SOUTH_WEST);
/*  44 */       Block eight = one.getRelative(BlockFace.SOUTH);
/*  45 */       Block nine = one.getRelative(BlockFace.SOUTH_EAST);
/*  46 */       Block ten = one.getRelative(BlockFace.EAST);
/*  47 */       Block two = one.getRelative(BlockFace.UP);
/*  48 */       Block eleven = two.getRelative(BlockFace.NORTH_WEST);
/*  49 */       Block twelve = two.getRelative(BlockFace.NORTH_EAST);
/*  50 */       Block thirteen = two.getRelative(BlockFace.NORTH);
/*  51 */       Block fourteen = two.getRelative(BlockFace.WEST);
/*  52 */       Block fivteen = two.getRelative(BlockFace.SOUTH_WEST);
/*  53 */       Block sixteen = two.getRelative(BlockFace.SOUTH);
/*  54 */       Block seventeen = two.getRelative(BlockFace.SOUTH_EAST);
/*  55 */       Block eightteen = two.getRelative(BlockFace.EAST);
/*  56 */       Block twentythree = two.getRelative(BlockFace.UP);
/*  57 */       Block nineteen = twentythree.getRelative(BlockFace.NORTH);
/*  58 */       Block twentyfour = twentythree.getRelative(BlockFace.NORTH_WEST);
/*  59 */       Block twentyfive = twentythree.getRelative(BlockFace.NORTH_EAST);
/*  60 */       Block twentysix = twentythree.getRelative(BlockFace.EAST);
/*  61 */       Block twentyseven = twentythree.getRelative(BlockFace.WEST);
/*  62 */       Block twenty = twentythree.getRelative(BlockFace.SOUTH_WEST);
/*  63 */       Block twentyone = twentythree.getRelative(BlockFace.SOUTH);
/*  64 */       Block twentytwo = twentythree.getRelative(BlockFace.SOUTH_EAST);
/*  65 */       if ((player.getLevel() > 9) && (one != null)) {
/*  66 */         one.setType(this.wallMaterial);
/*  67 */         one.setData(this.wallMaterialData);
/*  68 */         two.setType(this.wallMaterial);
/*  69 */         two.setData(this.wallMaterialData);
/*  70 */         three.setType(this.wallMaterial);
/*  71 */         three.setData(this.wallMaterialData);
/*  72 */         four.setType(this.wallMaterial);
/*  73 */         four.setData(this.wallMaterialData);
/*  74 */         five.setType(this.wallMaterial);
/*  75 */         five.setData(this.wallMaterialData);
/*  76 */         six.setType(this.wallMaterial);
/*  77 */         six.setData(this.wallMaterialData);
/*  78 */         seven.setType(this.wallMaterial);
/*  79 */         seven.setData(this.wallMaterialData);
/*  80 */         eight.setType(this.wallMaterial);
/*  81 */         eight.setData(this.wallMaterialData);
/*  82 */         nine.setType(this.wallMaterial);
/*  83 */         nine.setData(this.wallMaterialData);
/*  84 */         ten.setType(this.wallMaterial);
/*  85 */         ten.setData(this.wallMaterialData);
/*  86 */         eleven.setType(this.wallMaterial);
/*  87 */         eleven.setData(this.wallMaterialData);
/*  88 */         twelve.setType(this.wallMaterial);
/*  89 */         twelve.setData(this.wallMaterialData);
/*  90 */         thirteen.setType(this.wallMaterial);
/*  91 */         thirteen.setData(this.wallMaterialData);
/*  92 */         fourteen.setType(this.wallMaterial);
/*  93 */         fourteen.setData(this.wallMaterialData);
/*  94 */         fivteen.setType(this.wallMaterial);
/*  95 */         fivteen.setData(this.wallMaterialData);
/*  96 */         sixteen.setType(this.wallMaterial);
/*  97 */         sixteen.setData(this.wallMaterialData);
/*  98 */         seventeen.setType(this.wallMaterial);
/*  99 */         seventeen.setData(this.wallMaterialData);
/* 100 */         eightteen.setType(this.wallMaterial);
/* 101 */         eightteen.setData(this.wallMaterialData);
/* 102 */         nineteen.setType(this.wallMaterial);
/* 103 */         nineteen.setData(this.wallMaterialData);
/* 104 */         twenty.setType(this.wallMaterial);
/* 105 */         twenty.setData(this.wallMaterialData);
/* 106 */         twentyone.setType(this.wallMaterial);
/* 107 */         twentyone.setData(this.wallMaterialData);
/* 108 */         twentytwo.setType(this.wallMaterial);
/* 109 */         twentytwo.setData(this.wallMaterialData);
/* 110 */         twentythree.setType(this.wallMaterial);
/* 111 */         twentythree.setData(this.wallMaterialData);
/* 112 */         twentyfour.setType(this.wallMaterial);
/* 113 */         twentyfour.setData(this.wallMaterialData);
/* 114 */         twentyfive.setData(this.wallMaterialData);
/* 115 */         twentyfive.setType(this.wallMaterial);
/* 116 */         twentysix.setType(this.wallMaterial);
/* 117 */         twentysix.setData(this.wallMaterialData);
/* 118 */         twentyseven.setType(this.wallMaterial);
/* 119 */         twentyseven.setData(this.wallMaterialData);
/* 120 */         player.setLevel(player.getLevel() - 10);
/*     */       }
/* 122 */       else if (player.getLevel() < 9) {
/* 123 */         player.sendMessage(ChatColor.RED + "You need 10 levels to place a wall.");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler
/*     */   public void inventoryClick(InventoryClickEvent e) {
/* 130 */     Inventory inv = e.getInventory();
/*     */   }
/*     */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     survivors.survivorWall
 * JD-Core Version:    0.6.2
 */