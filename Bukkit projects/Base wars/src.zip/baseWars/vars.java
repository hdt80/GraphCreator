/*   */ package baseWars;
/*   */ 
/*   */ import org.bukkit.Location;
/*   */ 
/*   */ public class vars
/*   */ {
/* 6 */   public static Location monsterSpawn = null;
/* 7 */   public static Location survivorSpawn = null;
/* 8 */   public static Location obsSpawn = null;
/*   */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     baseWars.vars
 * JD-Core Version:    0.6.2
 */