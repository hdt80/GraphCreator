/*    */ package baseWars;
/*    */ 
/*    */ import java.util.logging.Logger;
/*    */ import listeners.BaseWarsListener;
/*    */ import listeners.CommandListener;
/*    */ import monsters.blazeAbilites;
/*    */ import monsters.creeperAbilites;
/*    */ import monsters.monsterAbilites;
/*    */ import monsters.silverfishAbilites;
/*    */ import monsters.spiderAbilites;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.command.PluginCommand;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.configuration.file.FileConfigurationOptions;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import survivors.survivorWall;
/*    */ 
/*    */ public class BaseWars extends JavaPlugin
/*    */ {
/* 15 */   public static boolean running = false;
/* 16 */   public static final Logger logger = Logger.getLogger("Minecraft");
/*    */   public static BaseWarsListener plugin;
/*    */   public FileConfiguration config;
/*    */ 
/*    */   public void onDisable()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void onEnable()
/*    */   {
/* 24 */     new BaseWarsListener(this);
/* 25 */     new survivorWall(this);
/* 26 */     new monsterAbilites(this);
/* 27 */     new spiderAbilites(this);
/* 28 */     new blazeAbilites(this);
/* 29 */     new silverfishAbilites(this);
/* 30 */     new creeperAbilites(this);
/* 31 */     getCommand("join").setExecutor(new CommandListener(this));
/* 32 */     getCommand("start").setExecutor(new CommandListener(this));
/* 33 */     getCommand("clonemap").setExecutor(new CommandListener(this));
/* 34 */     getCommand("setspawn").setExecutor(new CommandListener(this));
/* 35 */     getCommand("leave").setExecutor(new CommandListener(this));
/* 36 */     this.config = getConfig();
/*    */ 
/* 38 */     this.config.addDefault("Spawns.MonsterSpawn.x", Integer.valueOf(10));
/* 39 */     this.config.addDefault("Spawns.MonsterSpawn.y", Integer.valueOf(64));
/* 40 */     this.config.addDefault("Spawns.MonsterSpawn.z", Integer.valueOf(10));
/* 41 */     this.config.addDefault("Spawns.MonsterSpawn.pitch", Integer.valueOf(0));
/* 42 */     this.config.addDefault("Spawns.MonsterSpawn.yaw", Integer.valueOf(0));
/*    */ 
/* 44 */     this.config.addDefault("Spawns.SurvivorSpawn.x", Integer.valueOf(0));
/* 45 */     this.config.addDefault("Spawns.SurvivorSpawn.y", Integer.valueOf(64));
/* 46 */     this.config.addDefault("Spawns.SurvivorSpawn.z", Integer.valueOf(0));
/* 47 */     this.config.addDefault("Spawns.SurvivorSpawn.pitch", Integer.valueOf(0));
/* 48 */     this.config.addDefault("Spawns.SurvivorSpawn.yaw", Integer.valueOf(0));
/*    */ 
/* 50 */     this.config.addDefault("Spawns.ObsSpawn.x", Integer.valueOf(0));
/* 51 */     this.config.addDefault("Spawns.ObsSpawn.y", Integer.valueOf(64));
/* 52 */     this.config.addDefault("Spawns.ObsSpawn.z", Integer.valueOf(0));
/* 53 */     this.config.addDefault("Spawns.ObsSpawn.pitch", Integer.valueOf(0));
/* 54 */     this.config.addDefault("Spawns.ObsSpawn.yaw", Integer.valueOf(0));
/* 55 */     saveDefaultConfig();
/* 56 */     this.config.options().copyDefaults(true);
/* 57 */     saveConfig();
/* 58 */     vars.monsterSpawn = new Location(Bukkit.getWorld("world"), this.config.getInt("Spawns.MonsterSpawn.x"), 
/* 59 */       this.config.getInt("Spawns.MonsterSpawn.y"), this.config.getInt("Spawns.MonsterSpawn.z"), 
/* 60 */       this.config.getInt("Spawns.MonsterSpawn.yaw"), this.config.getInt("Spawns.MonsterSpawn.pitch"));
/*    */ 
/* 62 */     vars.survivorSpawn = new Location(Bukkit.getWorld("world"), this.config.getInt("Spawns.SurvivorSpawn.x"), 
/* 63 */       this.config.getInt("Spawns.SurvivorSpawn.y"), this.config.getInt("Spawns.SurvivorSpawn.z"), 
/* 64 */       this.config.getInt("Spawns.SurvivorSpawn.yaw"), this.config.getInt("Spawns.SurvivorSpawn.pitch"));
/*    */ 
/* 66 */     vars.obsSpawn = new Location(Bukkit.getWorld("world"), this.config.getInt("Spawns.ObsSpawn.x"), 
/* 67 */       this.config.getInt("Spawns.ObsSpawn.y"), this.config.getInt("Spawns.ObsSpawn.z"), 
/* 68 */       this.config.getInt("Spawns.ObsSpawn.yaw"), this.config.getInt("Spawns.ObsSpawn.pitch"));
/*    */   }
/*    */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     baseWars.BaseWars
 * JD-Core Version:    0.6.2
 */