/*     */ package baseWars;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.configuration.file.YamlConfigurationOptions;
/*     */ 
/*     */ public class PlayerFile
/*     */ {
/*  11 */   private File file = null;
/*     */ 
/*  13 */   private final YamlConfiguration yaml = new YamlConfiguration();
/*     */ 
/*     */   public PlayerFile(File file) {
/*  16 */     this.file = file;
/*     */ 
/*  18 */     if (!file.exists()) {
/*     */       try {
/*  20 */         file.createNewFile();
/*     */       } catch (IOException e) {
/*  22 */         e.printStackTrace();
/*     */       }
/*     */     }
/*  25 */     load();
/*     */   }
/*     */ 
/*     */   public PlayerFile(String path) {
/*  29 */     this.file = new File(path);
/*  30 */     if (!this.file.exists()) {
/*     */       try {
/*  32 */         this.file.createNewFile();
/*     */       } catch (IOException e) {
/*  34 */         e.printStackTrace();
/*     */       }
/*     */     }
/*  37 */     load();
/*     */   }
/*     */ 
/*     */   private void load() {
/*     */     try {
/*  42 */       this.yaml.load(this.file);
/*     */     } catch (Exception e) {
/*  44 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void save() {
/*     */     try {
/*  50 */       this.yaml.save(this.file);
/*     */     } catch (Exception e) {
/*  52 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delete() {
/*     */     try {
/*  58 */       this.file.delete();
/*     */     } catch (Exception e) {
/*  60 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getInteger(String s) {
/*  65 */     return this.yaml.getInt(s);
/*     */   }
/*     */ 
/*     */   public void reload() {
/*  69 */     save();
/*     */ 
/*  71 */     load();
/*     */   }
/*     */ 
/*     */   public String getString(String s) {
/*  75 */     return this.yaml.getString(s);
/*     */   }
/*     */ 
/*     */   public Object get(String s) {
/*  79 */     return this.yaml.get(s);
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String s) {
/*  83 */     return this.yaml.getBoolean(s);
/*     */   }
/*     */ 
/*     */   public void add(String s, Object o) {
/*  87 */     if (!contains(s))
/*  88 */       set(s, o);
/*     */   }
/*     */ 
/*     */   public void addToStringList(String s, String o)
/*     */   {
/*  93 */     this.yaml.getStringList(s).add(o);
/*     */   }
/*     */ 
/*     */   public void removeFromStringList(String s, String o) {
/*  97 */     this.yaml.getStringList(s).remove(o);
/*     */   }
/*     */ 
/*     */   public List<String> getStringList(String s) {
/* 101 */     return this.yaml.getStringList(s);
/*     */   }
/*     */ 
/*     */   public void addToIntegerList(String s, int o) {
/* 105 */     this.yaml.getIntegerList(s).add(Integer.valueOf(o));
/*     */   }
/*     */ 
/*     */   public void removeFromIntegerList(String s, int o) {
/* 109 */     this.yaml.getIntegerList(s).remove(o);
/*     */   }
/*     */ 
/*     */   public List<Integer> getIntegerList(String s) {
/* 113 */     return this.yaml.getIntegerList(s);
/*     */   }
/*     */ 
/*     */   public void createNewStringList(String s, List<String> list) {
/* 117 */     this.yaml.set(s, list);
/*     */   }
/*     */ 
/*     */   public void createNewIntegerList(String s, List<Integer> list) {
/* 121 */     this.yaml.set(s, list);
/*     */   }
/*     */ 
/*     */   public void remove(String s) {
/* 125 */     set(s, null);
/*     */   }
/*     */ 
/*     */   public boolean contains(String s) {
/* 129 */     return this.yaml.contains(s);
/*     */   }
/*     */ 
/*     */   public double getDouble(String s) {
/* 133 */     return this.yaml.getDouble(s);
/*     */   }
/*     */ 
/*     */   public void set(String s, Object o) {
/* 137 */     this.yaml.set(s, o);
/*     */   }
/*     */ 
/*     */   public void increment(String s) {
/* 141 */     this.yaml.set(s, Integer.valueOf(getInteger(s) + 1));
/*     */   }
/*     */ 
/*     */   public void decrement(String s) {
/* 145 */     this.yaml.set(s, Integer.valueOf(getInteger(s) - 1));
/*     */   }
/*     */ 
/*     */   public void increment(String s, int i) {
/* 149 */     this.yaml.set(s, Integer.valueOf(getInteger(s) + i));
/*     */   }
/*     */ 
/*     */   public void decrement(String s, int i) {
/* 153 */     this.yaml.set(s, Integer.valueOf(getInteger(s) - i));
/*     */   }
/*     */ 
/*     */   public YamlConfigurationOptions options() {
/* 157 */     return this.yaml.options();
/*     */   }
/*     */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     baseWars.PlayerFile
 * JD-Core Version:    0.6.2
 */