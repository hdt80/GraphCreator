/*     */ package listeners;
/*     */ 
/*     */ import baseWars.BaseWars;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.command.Command;
/*     */ import org.bukkit.command.CommandExecutor;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ public class CommandListener
/*     */   implements CommandExecutor
/*     */ {
/*     */   private final BaseWars plugin;
/*  35 */   public static HashMap<String, String> blueTeam = new HashMap();
/*  36 */   public static HashMap<String, String> redTeam = new HashMap();
/*     */ 
/*     */   public static ItemStack createItem(String name, Material item, String lore)
/*     */   {
/*  24 */     ItemStack i = new ItemStack(item);
/*  25 */     ItemMeta im = i.getItemMeta();
/*  26 */     im.setDisplayName(name);
/*  27 */     List loreLines = new ArrayList();
/*  28 */     loreLines.add(lore);
/*  29 */     im.setLore(loreLines);
/*  30 */     i.setItemMeta(im);
/*  31 */     return i;
/*     */   }
/*     */ 
/*     */   public CommandListener(BaseWars plugin)
/*     */   {
/*  39 */     this.plugin = plugin;
/*     */   }
/*     */ 
/*     */   public static Inventory teamInv() {
/*  43 */     Inventory inv = Bukkit.createInventory(null, 9, ChatColor.RED + 
/*  44 */       "Choose your team");
/*  45 */     inv.setItem(
/*  46 */       0, 
/*  47 */       createItem(ChatColor.AQUA + "Survivors", Material.EMERALD, 
/*  48 */       "Try to survive!"));
/*  49 */     inv.setItem(
/*  50 */       1, 
/*  51 */       createItem(ChatColor.WHITE + "Skeleton", Material.NETHER_WARTS, 
/*  52 */       ChatColor.RED + "KILL!"));
/*  53 */     return inv;
/*     */   }
/*     */ 
/*     */   public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args)
/*     */   {
/*  58 */     if ((sender instanceof Player)) {
/*  59 */       Player player = (Player)sender;
/*  60 */       if (cmd.getName().equalsIgnoreCase("join")) {
/*  61 */         if (args.length == 0) {
/*  62 */           HashMap team = getSmallerTeam();
/*  63 */           if (!team.containsKey(player.getName())) {
/*  64 */             team.put(null, player.getName());
/*  65 */             if (team == blueTeam) {
/*  66 */               player.sendMessage("Joined" + ChatColor.BLUE + 
/*  67 */                 "blue" + ChatColor.RESET + "team.");
/*  68 */               redTeam.remove(player.getName());
/*  69 */               player.setDisplayName(ChatColor.BLUE + 
/*  70 */                 player.getName() + ChatColor.WHITE);
/*  71 */               player.setPlayerListName(ChatColor.BLUE + 
/*  72 */                 player.getName() + ChatColor.WHITE);
/*  73 */               Bukkit.broadcastMessage(player.getName() + 
/*  74 */                 " has joined" + ChatColor.BLUE + " blue" + 
/*  75 */                 ChatColor.RESET + " team.");
/*  76 */             } else if (team == redTeam) {
/*  77 */               player.sendMessage("Joined" + ChatColor.RED + "red" + 
/*  78 */                 ChatColor.RESET + "team.");
/*  79 */               blueTeam.remove(player.getName());
/*  80 */               player.setDisplayName(ChatColor.RED + 
/*  81 */                 player.getName() + ChatColor.WHITE);
/*  82 */               player.setPlayerListName(ChatColor.RED + 
/*  83 */                 player.getName() + ChatColor.WHITE);
/*  84 */               Bukkit.broadcastMessage(player.getName() + 
/*  85 */                 " has joined" + ChatColor.RED + " red" + 
/*  86 */                 ChatColor.RESET + " team.");
/*     */             } else {
/*  88 */               player.sendMessage(ChatColor.LIGHT_PURPLE + 
/*  89 */                 "SOMETHING IS WRONG OH MAN HELP ME PLS");
/*  90 */               Bukkit.broadcastMessage("Someone messed up. Blame them.");
/*     */             }
/*     */           }
/*     */         } else {
/*  94 */           player.sendMessage(ChatColor.RED + "Usage: /join");
/*     */         }
/*     */       }
/*  97 */       if (cmd.getName().equalsIgnoreCase("Start")) {
/*  98 */         if (args.length != 0) {
/*  99 */           player.sendMessage("Only one arg");
/*     */         }
/* 101 */         if (args.length == 0) {
/* 102 */           BaseWars.running = !BaseWars.running;
/* 103 */           player.sendMessage("Now " + BaseWars.running);
/* 104 */           if (BaseWars.running) {
/* 105 */             for (Player p : Bukkit.getServer().getOnlinePlayers()) {
/* 106 */               p.openInventory(teamInv());
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 121 */       if ((cmd.getName().equalsIgnoreCase("setspawn")) && (player.isOp())) {
/* 122 */         if ((args.length == 0) || (args.length > 1)) {
/* 123 */           player.sendMessage("What spawn do you want to set? (m|s|o)");
/*     */         }
/* 125 */         if (args.length == 1) {
/* 126 */           String arg = "";
/* 127 */           for (String e : args) {
/* 128 */             arg = e.toUpperCase();
/*     */           }
/* 130 */           player.sendMessage(args);
/* 131 */           if ("MONSTER".startsWith(arg)) {
/* 132 */             baseWars.vars.monsterSpawn = player.getLocation();
/* 133 */             player.sendMessage("Set monster spawn to " + 
/* 134 */               (int)player.getLocation().getX() + ", " + 
/* 135 */               (int)player.getLocation().getY() + ", " + 
/* 136 */               (int)player.getLocation().getZ());
/*     */           }
/* 138 */           if ("SURVIVOR".startsWith(arg)) {
/* 139 */             baseWars.vars.survivorSpawn = player.getLocation();
/* 140 */             player.sendMessage("Set survivor spawn to " + 
/* 141 */               (int)player.getLocation().getX() + ", " + 
/* 142 */               (int)player.getLocation().getY() + ", " + 
/* 143 */               (int)player.getLocation().getZ());
/*     */           }
/* 145 */           if ("OBSERVER".startsWith(arg)) {
/* 146 */             baseWars.vars.obsSpawn = player.getLocation();
/* 147 */             player.sendMessage("Set observer spawn to " + 
/* 148 */               (int)player.getLocation().getX() + ", " + 
/* 149 */               (int)player.getLocation().getY() + ", " + 
/* 150 */               (int)player.getLocation().getZ());
/*     */           } else {
/* 152 */             player.sendMessage("That's not a valid team. (m|s|o)");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 158 */     return false;
/*     */   }
/*     */ 
/*     */   public HashMap<String, String> getSmallerTeam() {
/* 162 */     int red = redTeam.size();
/* 163 */     int blue = blueTeam.size();
/* 164 */     if (red > blue) {
/* 165 */       return blueTeam;
/*     */     }
/* 167 */     if (blue > red) {
/* 168 */       return redTeam;
/*     */     }
/* 170 */     return blueTeam;
/*     */   }
/*     */ 
/*     */   public HashMap<String, String> getPlayerteam(Player player) {
/* 174 */     if (blueTeam.containsKey(player.getName())) {
/* 175 */       return blueTeam;
/*     */     }
/* 177 */     if (redTeam.containsKey(player.getName())) {
/* 178 */       return redTeam;
/*     */     }
/* 180 */     return null;
/*     */   }
/*     */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     listeners.CommandListener
 * JD-Core Version:    0.6.2
 */