/*    */ package listeners;
/*    */ 
/*    */ import baseWars.BaseWars;
/*    */ import baseWars.vars;
/*    */ import java.util.logging.Logger;
/*    */ import monsters.monsterAbilites;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.entity.FoodLevelChangeEvent;
/*    */ import org.bukkit.event.player.PlayerRespawnEvent;
/*    */ import org.bukkit.event.weather.WeatherChangeEvent;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ 
/*    */ public class BaseWarsListener
/*    */   implements Listener
/*    */ {
/* 17 */   public final Logger logger = Logger.getLogger("Minecraft");
/*    */   private final BaseWars plugin;
/*    */ 
/*    */   public BaseWarsListener(BaseWars plugin)
/*    */   {
/* 21 */     this.plugin = plugin;
/* 22 */     plugin.getServer().getPluginManager().registerEvents(this, plugin);
/*    */   }
/*    */ 
/*    */   @EventHandler
/*    */   public void playerRespawnEvent(PlayerRespawnEvent e) {
/* 27 */     Player player = e.getPlayer();
/* 28 */     Bukkit.broadcastMessage(player.getName() + " Died. What a n3rd.");
/* 29 */     player.teleport(vars.obsSpawn);
/* 30 */     player.openInventory(monsterAbilites.monsterPickerInv());
/*    */   }
/*    */ 
/*    */   @EventHandler
/*    */   public void entityFoodLevelChange(FoodLevelChangeEvent e) {
/* 35 */     e.setCancelled(true);
/*    */   }
/*    */ 
/*    */   @EventHandler
/*    */   public void weatherChangeEvent(WeatherChangeEvent e) {
/* 40 */     e.setCancelled(true);
/*    */   }
/*    */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     listeners.BaseWarsListener
 * JD-Core Version:    0.6.2
 */