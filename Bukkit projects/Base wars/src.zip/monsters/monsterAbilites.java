/*     */ package monsters;
/*     */ 
/*     */ import baseWars.BaseWars;
/*     */ import baseWars.vars;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import pgDev.bukkit.DisguiseCraft.DisguiseCraft;
/*     */ import pgDev.bukkit.DisguiseCraft.api.DisguiseCraftAPI;
/*     */ import pgDev.bukkit.DisguiseCraft.disguise.Disguise;
/*     */ import pgDev.bukkit.DisguiseCraft.disguise.DisguiseType;
/*     */ 
/*     */ public class monsterAbilites extends JavaPlugin
/*     */   implements Listener
/*     */ {
/*     */   DisguiseCraftAPI dc;
/*  31 */   public static HashMap<Player, String> monsterClass = new HashMap();
/*     */   public static BaseWars plugin;
/*     */ 
/*     */   public void setupDisguiseCraft()
/*     */   {
/*  34 */     this.dc = DisguiseCraft.getAPI();
/*     */   }
/*     */ 
/*     */   public monsterAbilites(BaseWars plugin)
/*     */   {
/*  40 */     plugin = plugin;
/*  41 */     plugin.getServer().getPluginManager().registerEvents(this, plugin);
/*     */   }
/*     */ 
/*     */   public static ItemStack createItem(String name, Material item, String lore) {
/*  45 */     ItemStack i = new ItemStack(item);
/*  46 */     ItemMeta im = i.getItemMeta();
/*  47 */     im.setDisplayName(name);
/*  48 */     List loreLines = new ArrayList();
/*  49 */     loreLines.add(lore);
/*  50 */     im.setLore(loreLines);
/*  51 */     i.setItemMeta(im);
/*  52 */     return i;
/*     */   }
/*     */ 
/*     */   public static ItemStack createItem(String name, Material item, String lore, short data, int amount)
/*     */   {
/*  57 */     ItemStack i = new ItemStack(item, amount, data);
/*  58 */     ItemMeta im = i.getItemMeta();
/*  59 */     im.setDisplayName(name);
/*  60 */     List loreLines = new ArrayList();
/*  61 */     loreLines.add(lore);
/*  62 */     im.setLore(loreLines);
/*  63 */     i.setItemMeta(im);
/*  64 */     return i;
/*     */   }
/*     */ 
/*     */   public static ItemStack createItem(String name, Material item, String lore, short data)
/*     */   {
/*  69 */     ItemStack i = new ItemStack(item, 1, data);
/*  70 */     ItemMeta im = i.getItemMeta();
/*  71 */     im.setDisplayName(name);
/*  72 */     List loreLines = new ArrayList();
/*  73 */     loreLines.add(lore);
/*  74 */     im.setLore(loreLines);
/*  75 */     i.setItemMeta(im);
/*  76 */     return i;
/*     */   }
/*     */ 
/*     */   public static Inventory monsterPickerInv() {
/*  80 */     Inventory inv = Bukkit.createInventory(null, 9, ChatColor.RED + 
/*  81 */       "Choose your monster");
/*  82 */     inv.setItem(
/*  83 */       0, 
/*  84 */       createItem(ChatColor.AQUA + "Zombie", Material.ROTTEN_FLESH, 
/*  85 */       "Be a zombie!"));
/*  86 */     inv.setItem(
/*  87 */       1, 
/*  88 */       createItem(ChatColor.WHITE + "Skeleton", Material.BONE, 
/*  89 */       "Be a skeleton!"));
/*  90 */     inv.setItem(
/*  91 */       2, 
/*  92 */       createItem(ChatColor.BLACK + "Spider", Material.SPIDER_EYE, 
/*  93 */       "Be a spider!"));
/*  94 */     inv.setItem(
/*  95 */       3, 
/*  96 */       createItem(ChatColor.GREEN + "Creeper", Material.SULPHUR, 
/*  97 */       "Be a creeper!"));
/*  98 */     inv.setItem(
/*  99 */       4, 
/* 100 */       createItem(ChatColor.RED + "Blaze", Material.BLAZE_POWDER, 
/* 101 */       "Be a blaze!"));
/* 102 */     inv.setItem(
/* 103 */       5, 
/* 104 */       createItem(ChatColor.GRAY + "Silverfish", Material.STONE, 
/* 105 */       "Be a silverfish!"));
/* 106 */     return inv;
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.HIGHEST)
/*     */   public void onPlayerInteract(PlayerInteractEvent e) {
/* 111 */     Player player = e.getPlayer();
/* 112 */     if ((e.getAction() == Action.RIGHT_CLICK_BLOCK) || (e.getAction() == Action.RIGHT_CLICK_AIR))
/*     */     {
/* 114 */       if (player.getItemInHand().getType()
/* 114 */         .equals(Material.MAGMA_CREAM))
/* 115 */         player.openInventory(monsterPickerInv());
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler
/*     */   public void inventoryClick(InventoryClickEvent e) {
/* 121 */     Inventory inv = e.getInventory();
/* 122 */     if ((inv.getTitle().contains("Choose your monster")) && 
/* 123 */       ((e.getWhoClicked() instanceof Player))) {
/* 124 */       Player player = (Player)e.getWhoClicked();
/* 125 */       setupDisguiseCraft();
/*     */ 
/* 127 */       if (e.getCurrentItem().getType() == Material.SULPHUR) {
/* 128 */         e.setCancelled(true);
/* 129 */         if (BaseWars.running) {
/* 130 */           player.teleport(vars.monsterSpawn);
/* 131 */           if (this.dc.isDisguised(player))
/* 132 */             this.dc.changePlayerDisguise(player, 
/* 133 */               new Disguise(this.dc.newEntityID(), 
/* 134 */               DisguiseType.Creeper));
/*     */           else {
/* 136 */             this.dc.disguisePlayer(player, new Disguise(
/* 137 */               this.dc.newEntityID(), DisguiseType.Creeper));
/*     */           }
/* 139 */           player.sendMessage("You a now a creeper.");
/* 140 */           creeperAbilites.creeperMain(player);
/* 141 */           monsterClass.put(player, "creeper");
/* 142 */         } else if (!BaseWars.running) {
/* 143 */           player.sendMessage("Game hasn't started! Please wait for the game to start.");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 148 */       if (e.getCurrentItem().getType() == Material.ROTTEN_FLESH) {
/* 149 */         e.setCancelled(true);
/* 150 */         if (BaseWars.running) {
/* 151 */           player.teleport(vars.monsterSpawn);
/* 152 */           if (this.dc.isDisguised(player))
/* 153 */             this.dc.changePlayerDisguise(player, 
/* 154 */               new Disguise(this.dc.newEntityID(), 
/* 155 */               DisguiseType.Zombie));
/*     */           else {
/* 157 */             this.dc.disguisePlayer(player, new Disguise(
/* 158 */               this.dc.newEntityID(), DisguiseType.Zombie));
/*     */           }
/* 160 */           player.sendMessage("You a now a zombie.");
/* 161 */           zombieAbilites.zombieMain(player);
/* 162 */           monsterClass.put(player, "zombie");
/*     */         }
/* 164 */         else if (!BaseWars.running) {
/* 165 */           player.sendMessage("Game hasn't started! Please wait for the game to start.");
/*     */         }
/*     */       }
/*     */ 
/* 169 */       if (e.getCurrentItem().getType() == Material.BONE) {
/* 170 */         e.setCancelled(true);
/* 171 */         if (BaseWars.running) {
/* 172 */           player.teleport(vars.monsterSpawn);
/* 173 */           if (this.dc.isDisguised(player))
/* 174 */             this.dc.changePlayerDisguise(player, 
/* 175 */               new Disguise(this.dc.newEntityID(), 
/* 176 */               DisguiseType.Skeleton));
/*     */           else {
/* 178 */             this.dc.disguisePlayer(player, new Disguise(
/* 179 */               this.dc.newEntityID(), DisguiseType.Skeleton));
/*     */           }
/* 181 */           player.sendMessage("You a now a skeleton.");
/* 182 */           skeletonAbilites.skeletonMain(player);
/* 183 */           monsterClass.put(player, "skeleton");
/* 184 */         } else if (!BaseWars.running) {
/* 185 */           player.sendMessage("Game hasn't started! Please wait for the game to start.");
/*     */         }
/*     */       }
/*     */ 
/* 189 */       if (e.getCurrentItem().getType() == Material.SPIDER_EYE) {
/* 190 */         e.setCancelled(true);
/* 191 */         if (BaseWars.running) {
/* 192 */           player.teleport(vars.monsterSpawn);
/* 193 */           if (this.dc.isDisguised(player))
/* 194 */             this.dc.changePlayerDisguise(player, 
/* 195 */               new Disguise(this.dc.newEntityID(), 
/* 196 */               DisguiseType.Spider));
/*     */           else {
/* 198 */             this.dc.disguisePlayer(player, new Disguise(
/* 199 */               this.dc.newEntityID(), DisguiseType.Spider));
/*     */           }
/* 201 */           player.sendMessage("You a now a spider.");
/* 202 */           spiderAbilites.spiderMain(player);
/* 203 */           monsterClass.put(player, "spider");
/* 204 */         } else if (!BaseWars.running) {
/* 205 */           player.sendMessage("Game hasn't started! Please wait for the game to start.");
/*     */         }
/*     */       }
/*     */ 
/* 209 */       if (e.getCurrentItem().getType() == Material.BLAZE_POWDER) {
/* 210 */         e.setCancelled(true);
/* 211 */         if (BaseWars.running) {
/* 212 */           player.teleport(vars.monsterSpawn);
/* 213 */           if (this.dc.isDisguised(player))
/* 214 */             this.dc.changePlayerDisguise(player, 
/* 215 */               new Disguise(this.dc.newEntityID(), 
/* 216 */               DisguiseType.Creeper));
/*     */           else {
/* 218 */             this.dc.disguisePlayer(player, new Disguise(
/* 219 */               this.dc.newEntityID(), DisguiseType.Creeper));
/*     */           }
/* 221 */           player.sendMessage("You a now a blaze.");
/* 222 */           blazeAbilites.blazeMain(player);
/* 223 */           monsterClass.put(player, "blaze");
/*     */         }
/* 225 */         else if (!BaseWars.running) {
/* 226 */           player.sendMessage("Game hasn't started! Please wait for the game to start.");
/*     */         }
/*     */       }
/*     */ 
/* 230 */       if (e.getCurrentItem().getType() == Material.STONE) {
/* 231 */         e.setCancelled(true);
/* 232 */         if (BaseWars.running) {
/* 233 */           player.teleport(vars.monsterSpawn);
/* 234 */           if (this.dc.isDisguised(player))
/* 235 */             this.dc.changePlayerDisguise(player, 
/* 236 */               new Disguise(this.dc.newEntityID(), 
/* 237 */               DisguiseType.Creeper));
/*     */           else {
/* 239 */             this.dc.disguisePlayer(player, new Disguise(
/* 240 */               this.dc.newEntityID(), DisguiseType.Creeper));
/*     */           }
/* 242 */           player.sendMessage("You a now a silverfish.");
/* 243 */           silverfishAbilites.silverfishMain(player);
/* 244 */           monsterClass.put(player, "silverfish");
/*     */         }
/* 246 */         else if (!BaseWars.running) {
/* 247 */           player.sendMessage("Game hasn't started! Please wait for the game to start.");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     monsters.monsterAbilites
 * JD-Core Version:    0.6.2
 */