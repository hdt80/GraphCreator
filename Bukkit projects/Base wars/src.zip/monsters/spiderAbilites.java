/*    */ package monsters;
/*    */ 
/*    */ import baseWars.BaseWars;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.logging.Logger;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.PlayerInventory;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.bukkit.util.Vector;
/*    */ 
/*    */ public class spiderAbilites extends JavaPlugin
/*    */   implements Listener
/*    */ {
/* 24 */   public final Logger logger = Logger.getLogger("Minecraft");
/*    */   public static BaseWars plugin;
/*    */ 
/*    */   public static ItemStack createItem(String name, Material item, String lore)
/*    */   {
/* 28 */     ItemStack i = new ItemStack(item);
/* 29 */     ItemMeta im = i.getItemMeta();
/* 30 */     im.setDisplayName(name);
/* 31 */     List loreLines = new ArrayList();
/* 32 */     loreLines.add(lore);
/* 33 */     im.setLore(loreLines);
/* 34 */     i.setItemMeta(im);
/* 35 */     return i;
/*    */   }
/*    */ 
/*    */   public spiderAbilites(BaseWars plugin) {
/* 39 */     plugin = plugin;
/* 40 */     plugin.getServer().getPluginManager().registerEvents(this, plugin);
/*    */   }
/*    */ 
/*    */   public static void spiderMain(Player player) {
/* 44 */     player.getInventory().clear();
/* 45 */     ItemStack spiderMainWep = createItem("Poison", Material.FERMENTED_SPIDER_EYE, "Poison your foes");
/* 46 */     ItemStack spiderSecondWep = createItem("Blindness", Material.INK_SACK, "Blind your enemies");
/* 47 */     ItemStack spiderThirdWep = createItem("Nasuea", Material.MELON_SEEDS, "Make 'em throw up");
/* 48 */     ItemStack spiderArmorHead = createItem("Spider helmet", Material.IRON_HELMET, "Basic spider helmet");
/* 49 */     ItemStack spiderArmorChest = createItem("Spider chestplate", Material.IRON_CHESTPLATE, 
/* 50 */       "Basic zombie chestplate");
/* 51 */     ItemStack spiderArmorLegs = createItem("Spider leggings", Material.IRON_LEGGINGS, "Basic spider leggings");
/* 52 */     ItemStack spiderArmorFeet = createItem("Spider boots", Material.IRON_BOOTS, "Basic spider boots");
/* 53 */     player.setHealthScale(20.0D);
/* 54 */     player.getInventory().addItem(new ItemStack[] { spiderMainWep });
/* 55 */     player.getInventory().addItem(new ItemStack[] { spiderSecondWep });
/* 56 */     player.getInventory().addItem(new ItemStack[] { spiderThirdWep });
/* 57 */     player.getInventory().addItem(new ItemStack[] { spiderArmorHead });
/* 58 */     player.getInventory().addItem(new ItemStack[] { spiderArmorChest });
/* 59 */     player.getInventory().addItem(new ItemStack[] { spiderArmorLegs });
/* 60 */     player.getInventory().addItem(new ItemStack[] { spiderArmorFeet });
/* 61 */     player.updateInventory();
/*    */   }
/*    */ 
/*    */   @EventHandler(priority=EventPriority.HIGHEST)
/*    */   public void onPlayerInteract(PlayerInteractEvent e) {
/* 66 */     Player player = e.getPlayer();
/* 67 */     if ((e.getAction() == Action.RIGHT_CLICK_BLOCK) || (e.getAction() == Action.RIGHT_CLICK_AIR)) {
/* 68 */       if ((player.getItemInHand().getType().equals(Material.FEATHER)) && (player.isOnGround())) {
/* 69 */         Vector v = player.getLocation().getDirection();
/* 70 */         v.setY(1).normalize().multiply(1).setY(1);
/* 71 */         player.setVelocity(v);
/*    */       }
/*    */ 
/* 74 */       if (player.getItemInHand().getType().equals(Material.FERMENTED_SPIDER_EYE)) {
/* 75 */         List ent = player.getNearbyEntities(10.0D, 10.0D, 10.0D);
/* 76 */         for (Entity entity : ent) {
/* 77 */           if ((player.hasLineOfSight(entity)) && ((entity instanceof Player))) {
/* 78 */             Player p = (Player)entity;
/* 79 */             p.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 80, 0));
/*    */           }
/*    */         }
/*    */       }
/*    */ 
/* 84 */       if (player.getItemInHand().getType().equals(Material.INK_SACK)) {
/* 85 */         List ent = player.getNearbyEntities(10.0D, 10.0D, 10.0D);
/* 86 */         for (Entity entity : ent) {
/* 87 */           if ((player.hasLineOfSight(entity)) && ((entity instanceof Player))) {
/* 88 */             Player p = (Player)entity;
/* 89 */             p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 80, 0));
/*    */           }
/*    */         }
/*    */       }
/*    */ 
/* 94 */       if (player.getItemInHand().getType().equals(Material.MELON_SEEDS)) {
/* 95 */         List ent = player.getNearbyEntities(10.0D, 10.0D, 10.0D);
/* 96 */         for (Entity entity : ent)
/* 97 */           if ((player.hasLineOfSight(entity)) && ((entity instanceof Player))) {
/* 98 */             Player p = (Player)entity;
/* 99 */             p.addPotionEffect(new PotionEffect(PotionEffectType.CONFUSION, 80, 0));
/*    */           }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     monsters.spiderAbilites
 * JD-Core Version:    0.6.2
 */