/*    */ package monsters;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.PlayerInventory;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ 
/*    */ public class zombieAbilites
/*    */ {
/*    */   public static ItemStack createItem(String name, Material item, String lore)
/*    */   {
/* 13 */     ItemStack i = new ItemStack(item);
/* 14 */     ItemMeta im = i.getItemMeta();
/* 15 */     im.setDisplayName(name);
/* 16 */     List loreLines = new ArrayList();
/* 17 */     loreLines.add(lore);
/* 18 */     im.setLore(loreLines);
/* 19 */     i.setItemMeta(im);
/* 20 */     return i;
/*    */   }
/*    */ 
/*    */   public static ItemStack createItem(String name, Material item, String lore, short data, int amount) {
/* 24 */     ItemStack i = new ItemStack(item, amount, data);
/* 25 */     ItemMeta im = i.getItemMeta();
/* 26 */     im.setDisplayName(name);
/* 27 */     List loreLines = new ArrayList();
/* 28 */     loreLines.add(lore);
/* 29 */     im.setLore(loreLines);
/* 30 */     i.setItemMeta(im);
/* 31 */     return i;
/*    */   }
/*    */ 
/*    */   public static ItemStack createItem(String name, Material item, String lore, short data) {
/* 35 */     ItemStack i = new ItemStack(item, 1, data);
/* 36 */     ItemMeta im = i.getItemMeta();
/* 37 */     im.setDisplayName(name);
/* 38 */     List loreLines = new ArrayList();
/* 39 */     loreLines.add(lore);
/* 40 */     im.setLore(loreLines);
/* 41 */     i.setItemMeta(im);
/* 42 */     return i;
/*    */   }
/*    */ 
/*    */   public static void zombieMain(Player player) {
/* 46 */     player.getInventory().clear();
/* 47 */     ItemStack zombieMainWep = createItem("Zombie sword", Material.IRON_SWORD, "Basic zombie sword");
/* 48 */     ItemStack zombieArmorHead = createItem("Zombie helmet", Material.IRON_HELMET, "Basic zombie helmet");
/* 49 */     ItemStack zombieArmorChest = createItem("Zombie chestplate", Material.IRON_CHESTPLATE, 
/* 50 */       "Basic zombie chestplate");
/* 51 */     ItemStack zombieArmorLegs = createItem("Zombie leggings", Material.IRON_LEGGINGS, "Basic zombie leggings");
/* 52 */     ItemStack zombieArmorFeet = createItem("Zombie boots", Material.IRON_BOOTS, "Basic zombie boots");
/* 53 */     player.setHealthScale(20.0D);
/* 54 */     player.getInventory().addItem(new ItemStack[] { zombieMainWep });
/* 55 */     player.getInventory().addItem(new ItemStack[] { zombieArmorHead });
/* 56 */     player.getInventory().addItem(new ItemStack[] { zombieArmorChest });
/* 57 */     player.getInventory().addItem(new ItemStack[] { zombieArmorLegs });
/* 58 */     player.getInventory().addItem(new ItemStack[] { zombieArmorFeet });
/* 59 */     player.updateInventory();
/*    */   }
/*    */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     monsters.zombieAbilites
 * JD-Core Version:    0.6.2
 */