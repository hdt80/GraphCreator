/*    */ package monsters;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.PlayerInventory;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ 
/*    */ public class skeletonAbilites
/*    */   implements Listener
/*    */ {
/*    */   public static ItemStack createItem(String name, Material item, String lore, int amount)
/*    */   {
/* 19 */     ItemStack i = new ItemStack(item, amount, (short)1);
/* 20 */     ItemMeta im = i.getItemMeta();
/* 21 */     im.setDisplayName(name);
/* 22 */     List loreLines = new ArrayList();
/* 23 */     loreLines.add(lore);
/* 24 */     im.setLore(loreLines);
/* 25 */     i.setItemMeta(im);
/* 26 */     return i;
/*    */   }
/*    */   public static ItemStack createItem(String name, Material item, String lore) {
/* 29 */     ItemStack i = new ItemStack(item);
/* 30 */     ItemMeta im = i.getItemMeta();
/* 31 */     im.setDisplayName(name);
/* 32 */     List loreLines = new ArrayList();
/* 33 */     loreLines.add(lore);
/* 34 */     im.setLore(loreLines);
/* 35 */     i.setItemMeta(im);
/* 36 */     return i;
/*    */   }
/*    */   @EventHandler(priority=EventPriority.HIGHEST)
/*    */   public void onPlayerInteract(PlayerInteractEvent e) {
/* 40 */     Player player = e.getPlayer();
/* 41 */     if (((e.getAction() == Action.LEFT_CLICK_BLOCK) || 
/* 42 */       (e.getAction() == Action.LEFT_CLICK_AIR)) && 
/* 43 */       (player.getItemInHand().getType() == Material.BOW))
/* 44 */       if (player.getLevel() >= 1) {
/* 45 */         player.getInventory()
/* 46 */           .addItem(new ItemStack[] { 
/* 47 */           createItem(
/* 48 */           "Arrow", 
/* 49 */           Material.ARROW, 
/* 50 */           "It's an arrow. What do you want here.", 
/* 51 */           8) });
/* 52 */         player.setLevel(player.getLevel() - 1);
/* 53 */       } else if (player.getLevel() > 1) {
/* 54 */         player.sendMessage("You need a level to summon more arrows.");
/*    */       }
/*    */   }
/*    */ 
/*    */   public static void skeletonMain(Player player)
/*    */   {
/* 60 */     player.getInventory().clear();
/* 61 */     ItemStack skeletonMainWep = createItem("Skeleton bow", 
/* 62 */       Material.BOW, "Basic Skeleton bow");
/* 63 */     ItemStack skeletonArmorHead = createItem("Skeleton helmet", 
/* 64 */       Material.LEATHER_HELMET, "Basic Skeleton helmet");
/* 65 */     ItemStack skeletonArmorChest = createItem("Skeleton chestplate", 
/* 66 */       Material.LEATHER_CHESTPLATE, "Basic Skeleton chestplate");
/* 67 */     ItemStack skeletonArmorLegs = createItem("Skeleton leggings", 
/* 68 */       Material.LEATHER_LEGGINGS, "Basic Skeleton leggings");
/* 69 */     ItemStack skeletonArmorFeet = createItem("Skeleton boots", 
/* 70 */       Material.LEATHER_BOOTS, "Basic Skeleton boots");
/* 71 */     player.setHealthScale(20.0D);
/* 72 */     player.getInventory().addItem(new ItemStack[] { skeletonMainWep });
/* 73 */     player.getInventory().addItem(new ItemStack[] { skeletonArmorHead });
/* 74 */     player.getInventory().addItem(new ItemStack[] { skeletonArmorChest });
/* 75 */     player.getInventory().addItem(new ItemStack[] { skeletonArmorLegs });
/* 76 */     player.getInventory().addItem(new ItemStack[] { skeletonArmorFeet });
/* 77 */     player.updateInventory();
/*    */   }
/*    */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     monsters.skeletonAbilites
 * JD-Core Version:    0.6.2
 */