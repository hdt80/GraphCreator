/*    */ package monsters;
/*    */ 
/*    */ import baseWars.BaseWars;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.logging.Logger;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.entity.TNTPrimed;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.PlayerInventory;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ import org.bukkit.util.Vector;
/*    */ 
/*    */ public class blazeAbilites extends JavaPlugin
/*    */   implements Listener
/*    */ {
/* 29 */   public final Logger logger = Logger.getLogger("Minecraft");
/*    */   public static BaseWars plugin;
/*    */ 
/*    */   public blazeAbilites(BaseWars plugin)
/*    */   {
/* 33 */     plugin = plugin;
/* 34 */     plugin.getServer().getPluginManager().registerEvents(this, plugin);
/*    */   }
/*    */ 
/*    */   public static ItemStack createItem(String name, Material item, String lore) {
/* 38 */     ItemStack i = new ItemStack(item);
/* 39 */     ItemMeta im = i.getItemMeta();
/* 40 */     im.setDisplayName(name);
/* 41 */     List loreLines = new ArrayList();
/* 42 */     loreLines.add(lore);
/* 43 */     im.setLore(loreLines);
/* 44 */     i.setItemMeta(im);
/* 45 */     return i;
/*    */   }
/*    */ 
/*    */   @EventHandler(priority=EventPriority.HIGHEST)
/*    */   public void onPlayerInteract(PlayerInteractEvent e) {
/* 50 */     Player player = e.getPlayer();
/* 51 */     if (((e.getAction() == Action.RIGHT_CLICK_BLOCK) || (e.getAction() == Action.RIGHT_CLICK_AIR)) && 
/* 52 */       (player.getItemInHand().getType().equals(Material.BLAZE_ROD)))
/* 53 */       if ((monsterAbilites.monsterClass.get(player) != null) && 
/* 54 */         (((String)monsterAbilites.monsterClass.get(player)).equals("blaze"))) {
/* 55 */         if (player.getLevel() >= 5) {
/* 56 */           player.addPotionEffect(new PotionEffect(
/* 57 */             PotionEffectType.SLOW, 150, 3));
/* 58 */           Entity entity = null;
/* 59 */           World world = player.getWorld();
/* 60 */           double speedFactor = 1.5D;
/* 61 */           Location fireLocation = player.getLocation();
/* 62 */           fireLocation.setY(fireLocation.getY() + 1.0D);
/* 63 */           Vector direction = fireLocation.getDirection();
/* 64 */           entity = world.spawn(fireLocation, TNTPrimed.class);
/* 65 */           entity.setVelocity(direction.multiply(speedFactor));
/* 66 */           player.setLevel(player.getLevel() - 5);
/* 67 */         } else if (player.getLevel() < 5) {
/* 68 */           player.sendMessage("You need a 5 levels to launch tnt. You have " + 
/* 69 */             ChatColor.GOLD + 
/* 70 */             player.getLevel() + 
/* 71 */             ChatColor.RESET + " level(s)");
/*    */         }
/*    */       }
/* 74 */       else player.sendMessage("I don't know how you got this stuff, but you're class has got to be a blaze");
/*    */   }
/*    */ 
/*    */   public static void blazeMain(Player player)
/*    */   {
/* 80 */     player.getInventory().clear();
/* 81 */     ItemStack blazeMainWep = createItem("Fireball", Material.BLAZE_ROD, 
/* 82 */       "Right click to launch tnt. Will give you slowness.");
/* 83 */     ItemStack blazeArmorHead = createItem("Blaze helmet", 
/* 84 */       Material.IRON_HELMET, "Basic blaze helmet");
/* 85 */     ItemStack blazeArmorChest = createItem("Blaze chestplate", 
/* 86 */       Material.IRON_CHESTPLATE, "Basic blaze chestplate");
/* 87 */     ItemStack blazeArmorLegs = createItem("Blaze leggings", 
/* 88 */       Material.IRON_LEGGINGS, "Basic blaze leggings");
/* 89 */     ItemStack blazeArmorFeet = createItem("Blaze boots", 
/* 90 */       Material.IRON_BOOTS, "Basic blaze boots");
/* 91 */     player.setHealthScale(20.0D);
/* 92 */     player.getInventory().addItem(new ItemStack[] { blazeMainWep });
/* 93 */     player.getInventory().addItem(new ItemStack[] { blazeArmorHead });
/* 94 */     player.getInventory().addItem(new ItemStack[] { blazeArmorChest });
/* 95 */     player.getInventory().addItem(new ItemStack[] { blazeArmorLegs });
/* 96 */     player.getInventory().addItem(new ItemStack[] { blazeArmorFeet });
/* 97 */     player.updateInventory();
/*    */   }
/*    */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     monsters.blazeAbilites
 * JD-Core Version:    0.6.2
 */