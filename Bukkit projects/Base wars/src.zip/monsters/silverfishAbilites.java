/*    */ package monsters;
/*    */ 
/*    */ import baseWars.BaseWars;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.PlayerInventory;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ 
/*    */ public class silverfishAbilites
/*    */   implements Listener
/*    */ {
/*    */   private final BaseWars plugin;
/*    */ 
/*    */   public silverfishAbilites(BaseWars plugin)
/*    */   {
/* 25 */     this.plugin = plugin;
/* 26 */     plugin.getServer().getPluginManager().registerEvents(this, plugin);
/*    */   }
/*    */   public static ItemStack createItem(String name, Material item, String lore) {
/* 29 */     ItemStack i = new ItemStack(item);
/* 30 */     ItemMeta im = i.getItemMeta();
/* 31 */     im.setDisplayName(name);
/* 32 */     List loreLines = new ArrayList();
/* 33 */     loreLines.add(lore);
/* 34 */     im.setLore(loreLines);
/* 35 */     i.setItemMeta(im);
/* 36 */     return i;
/*    */   }
/*    */ 
/*    */   public static ItemStack createItem(String name, Material item, String lore, short data, int amount)
/*    */   {
/* 41 */     ItemStack i = new ItemStack(item, amount, data);
/* 42 */     ItemMeta im = i.getItemMeta();
/* 43 */     im.setDisplayName(name);
/* 44 */     List loreLines = new ArrayList();
/* 45 */     loreLines.add(lore);
/* 46 */     im.setLore(loreLines);
/* 47 */     i.setItemMeta(im);
/* 48 */     return i;
/*    */   }
/*    */ 
/*    */   public static ItemStack createItem(String name, Material item, String lore, short data)
/*    */   {
/* 53 */     ItemStack i = new ItemStack(item, 1, data);
/* 54 */     ItemMeta im = i.getItemMeta();
/* 55 */     im.setDisplayName(name);
/* 56 */     List loreLines = new ArrayList();
/* 57 */     loreLines.add(lore);
/* 58 */     im.setLore(loreLines);
/* 59 */     i.setItemMeta(im);
/* 60 */     return i;
/*    */   }
/*    */   public static void silverfishMain(Player player) {
/* 63 */     player.getInventory().clear();
/* 64 */     ItemStack silverfishMainWep = createItem("Fangs", Material.DIAMOND_SWORD, 
/* 65 */       "Right clicking makes you invisible for 5 seconds.");
/* 66 */     player.setHealthScale(2.0D);
/* 67 */     player.getInventory().addItem(new ItemStack[] { silverfishMainWep });
/* 68 */     player.updateInventory();
/*    */   }
/*    */   @EventHandler
/*    */   public void playerInteractEvent(PlayerInteractEvent e) {
/* 72 */     Player player = e.getPlayer();
/* 73 */     if ((e.getAction() == Action.RIGHT_CLICK_AIR) || 
/* 74 */       (e.getAction() == Action.RIGHT_CLICK_BLOCK))
/*    */     {
/* 76 */       if (player.getItemInHand().getType() == Material.DIAMOND_SWORD)
/* 77 */         if (player.getLevel() >= 5) {
/* 78 */           player.addPotionEffect(new PotionEffect(
/* 79 */             PotionEffectType.INVISIBILITY, 150, 1));
/* 80 */           player.setLevel(player.getLevel() - 5);
/* 81 */         } else if (player.getLevel() < 5) {
/* 82 */           player.sendMessage("You need 5 levels to go invisible");
/*    */         }
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     monsters.silverfishAbilites
 * JD-Core Version:    0.6.2
 */