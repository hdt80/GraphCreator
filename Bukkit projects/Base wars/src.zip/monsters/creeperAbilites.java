/*    */ package monsters;
/*    */ 
/*    */ import baseWars.BaseWars;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.PlayerInventory;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ 
/*    */ public class creeperAbilites
/*    */   implements Listener
/*    */ {
/*    */   private final BaseWars plugin;
/*    */ 
/*    */   public creeperAbilites(BaseWars plugin)
/*    */   {
/* 22 */     this.plugin = plugin;
/* 23 */     plugin.getServer().getPluginManager().registerEvents(this, plugin);
/*    */   }
/*    */   public static ItemStack createItem(String name, Material item, String lore) {
/* 26 */     ItemStack i = new ItemStack(item);
/* 27 */     ItemMeta im = i.getItemMeta();
/* 28 */     im.setDisplayName(name);
/* 29 */     List loreLines = new ArrayList();
/* 30 */     loreLines.add(lore);
/* 31 */     im.setLore(loreLines);
/* 32 */     i.setItemMeta(im);
/* 33 */     return i;
/*    */   }
/*    */ 
/*    */   public static ItemStack createItem(String name, Material item, String lore, short data, int amount) {
/* 37 */     ItemStack i = new ItemStack(item, amount, data);
/* 38 */     ItemMeta im = i.getItemMeta();
/* 39 */     im.setDisplayName(name);
/* 40 */     List loreLines = new ArrayList();
/* 41 */     loreLines.add(lore);
/* 42 */     im.setLore(loreLines);
/* 43 */     i.setItemMeta(im);
/* 44 */     return i;
/*    */   }
/*    */ 
/*    */   public static ItemStack createItem(String name, Material item, String lore, short data) {
/* 48 */     ItemStack i = new ItemStack(item, 1, data);
/* 49 */     ItemMeta im = i.getItemMeta();
/* 50 */     im.setDisplayName(name);
/* 51 */     List loreLines = new ArrayList();
/* 52 */     loreLines.add(lore);
/* 53 */     im.setLore(loreLines);
/* 54 */     i.setItemMeta(im);
/* 55 */     return i;
/*    */   }
/*    */ 
/*    */   public static void creeperMain(Player player) {
/* 59 */     player.getInventory().clear();
/* 60 */     ItemStack creeperMainWep = createItem("Blow up!", Material.TNT, "What do you think this does?");
/* 61 */     player.setHealthScale(20.0D);
/* 62 */     player.getInventory().addItem(new ItemStack[] { creeperMainWep });
/* 63 */     player.updateInventory();
/*    */   }
/*    */   @EventHandler
/*    */   public void playerInteractEvent(PlayerInteractEvent e) {
/* 67 */     Player player = e.getPlayer();
/* 68 */     if (((e.getAction() == Action.LEFT_CLICK_AIR) || (e.getAction() == Action.LEFT_CLICK_BLOCK)) && 
/* 69 */       (player.getItemInHand().getType() == Material.TNT)) {
/* 70 */       Location playerLocation = player.getLocation();
/* 71 */       World world = player.getLocation().getWorld();
/* 72 */       world.createExplosion(playerLocation, 1.0F, true);
/* 73 */       player.setHealth(0.0D);
/*    */     }
/*    */   }
/*    */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     monsters.creeperAbilites
 * JD-Core Version:    0.6.2
 */