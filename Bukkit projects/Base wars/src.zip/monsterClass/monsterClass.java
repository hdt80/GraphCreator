/*    */ package monsterClass;
/*    */ 
/*    */ import org.bukkit.metadata.MetadataValue;
/*    */ import org.bukkit.plugin.Plugin;
/*    */ 
/*    */ public class monsterClass
/*    */   implements MetadataValue
/*    */ {
/*    */   Object value;
/*    */   Plugin p;
/*    */ 
/*    */   public monsterClass(Plugin p, Object o)
/*    */   {
/* 12 */     this.p = p;
/* 13 */     this.value = o;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 18 */     return this.value.equals(obj);
/*    */   }
/*    */ 
/*    */   public void set(Object o) {
/* 22 */     this.value = o;
/*    */   }
/*    */ 
/*    */   public boolean asBoolean()
/*    */   {
/* 27 */     throw new NullPointerException();
/*    */   }
/*    */ 
/*    */   public byte asByte()
/*    */   {
/* 32 */     throw new NullPointerException();
/*    */   }
/*    */ 
/*    */   public double asDouble()
/*    */   {
/* 37 */     throw new NullPointerException();
/*    */   }
/*    */ 
/*    */   public float asFloat()
/*    */   {
/* 42 */     throw new NullPointerException();
/*    */   }
/*    */ 
/*    */   public int asInt()
/*    */   {
/* 47 */     throw new NullPointerException();
/*    */   }
/*    */ 
/*    */   public long asLong()
/*    */   {
/* 52 */     throw new NullPointerException();
/*    */   }
/*    */ 
/*    */   public short asShort()
/*    */   {
/* 57 */     throw new NullPointerException();
/*    */   }
/*    */ 
/*    */   public String asString()
/*    */   {
/* 62 */     throw new NullPointerException();
/*    */   }
/*    */ 
/*    */   public Plugin getOwningPlugin()
/*    */   {
/* 67 */     return this.p;
/*    */   }
/*    */ 
/*    */   public void invalidate()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Object value()
/*    */   {
/* 78 */     return this.value;
/*    */   }
/*    */ }

/* Location:           F:\Programming\jd-gui-0.3.5.windows\baseWars.jar
 * Qualified Name:     monsterClass.monsterClass
 * JD-Core Version:    0.6.2
 */